# API Freshy bar

## запросы

// GET /api/goods - возвращает данные из файла db.json

// GET /img/:filename - возвращает изображение по имени filename

// POST /api/order - оформляет заказ с полями имя, телефон и массив с товарами

